# paint.py
import numpy as np
import cv2

paintWindow = np.zeros((471, 636, 3)) + 255
cv2.rectangle(paintWindow, (160, 1), (255, 65), (255, 0, 0), -1)
cv2.putText(paintWindow, "PAINT", (180, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)

cv2.imshow("Paint", paintWindow)
cv2.waitKey(0)
cv2.destroyAllWindows()
