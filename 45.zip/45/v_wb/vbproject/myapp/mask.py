# # mask.py
# import cv2
# import numpy as np

# cap = cv2.VideoCapture(0)
# kernel = np.ones((5, 5), np.uint8)

# while True:
#     ret, frame = cap.read()
#     frame = cv2.flip(frame, 1)
#     hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

#     lower = np.array([64, 171, 78])
#     upper = np.array([153, 255, 255])

#     mask = cv2.inRange(hsv, lower, upper)
#     mask = cv2.erode(mask, kernel, iterations=1)
#     mask = cv2.dilate(mask, kernel, iterations=1)

#     cv2.imshow("Mask", mask)

#     if cv2.waitKey(1) & 0xFF == ord("q"):
#         break

# cap.release()
# cv2.destroyAllWindows()
