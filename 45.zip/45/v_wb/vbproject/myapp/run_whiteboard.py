import subprocess
import os
def launch_whiteboard():
    subprocess.Popen(["python", os.path.abspath("myapp/demo.py")], shell=True)


# def launch_tracking():
#      subprocess.Popen(f'start python "{os.path.abspath("myapp/tracking.py")}"', shell=True)

# def launch_mask():
#     subprocess.Popen(f'start python "{os.path.abspath("myapp/mask.py")}"', shell=True)

# def launch_paint():
#     subprocess.Popen(f'start python "{os.path.abspath("myapp/paint.py")}"', shell=True)
