# # your_app/views.py

# from django.shortcuts import render
# from django.http import JsonResponse
# from myapp.run_whiteboard import launch_whiteboard

# def start_whiteboard(request):
#     launch_whiteboard()
#     return JsonResponse({'status': 'started'})

# def home_view(request):
#     return render(request, 'home.html')

# from django.http import JsonResponse
# from myapp.run_whiteboard import launch_tracking  #,launch_mask, launch_paint


# def start_tracking(request):
#     launch_tracking()
#     return JsonResponse({'status': 'tracking_started'})

# # def start_mask(request):
# #     launch_mask()
# #     return JsonResponse({'status': 'mask_started'})

# # def start_paint(request):
# #     launch_paint()
# #     return JsonResponse({'status': 'paint_started'})
from django.http import JsonResponse
from django.http import HttpResponse
from django.shortcuts import render
import subprocess
import os
import sys

def home(request):
    return render(request, 'home.html')
def run_track(request):
    subprocess.Popen(["python", "track.py"])
    return HttpResponse("Tracking started")

def start_whiteboard(request):
    try:
        script_path = os.path.join(os.path.dirname(__file__), 'demo.py')
        subprocess.Popen([sys.executable, script_path])
        return JsonResponse({'status': 'started'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
from django.shortcuts import render
from django.http import HttpResponse
import subprocess

def home(request):
    return render(request, 'home.html')


