# from django.urls import path
# from myapp.views import start_whiteboard, home_view
# from django.urls import path
# from myapp.views import start_tracking #start_mask, start_paint

# urlpatterns = [
#     path('start/', start_tracking, name='start_tracking'),
#     # path('mask/', start_mask, name='start_mask'),
#     # path('paint/', start_paint, name='start_paint'),
#     path('', home_view, name='home'),  # Root URL: /
#     path('start/', start_whiteboard, name='start_whiteboard'),
# ]
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('start', views.start_whiteboard, name='start_whiteboard'),
]
from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.home, name='home'),
    path('start', views.start_whiteboard, name='start_whiteboard'),
]
